﻿//APPEND COM JQUERY 
var ObjetojavaScript = new Object();

// DICA ( FUNÇÃO TESTAR CAMPOS )
ObjetojavaScript.TestaCampo = function (valor) {

    if (valor != null && valor != '' && valor != undefined)
       return  true;
    else
       return  false;
}

ObjetojavaScript.GerarCampos = function () {

    var qtdCampos = $('#campo').val();

    if (ObjetojavaScript.TestaCampo(qtdCampos)) {

        var DivNova = $('<div>').attr({ id: "minhadiv" });

        var meusElementos = "";

        for (var i = 1; i <= parseInt(qtdCampos); i++) {

            meusElementos += "<label> Meu Campo_" + i.toString() + " </label>";
            meusElementos += " <input type='text' id ='campo_ " + i.toString() + "' /></br>"
        }

        DivNova.append(meusElementos);

        $('#div_append').append(DivNova);

        $('#campo').val("");
    }
    else {
        alert('Digite um valor');
    }

}

ObjetojavaScript.limparTela = function () {
    $('#div_append').html('');

    //or

    $('#div_append').empty();

}
//////////////////////

//COMPORTAMENTOS
var ObjetoTela = new Object();

ObjetoTela.validaTela = function () {

    // DICAS DE UTILIZAÇÃO DE FUNÇÃO PARA VALIDAR TODOS OS CAMPOS
    if (ObjetojavaScript.TestaCampo($("#valor2").val()) && ObjetojavaScript.TestaCampo($("#valor1").val())) {

        var resposta = parseInt($("#valor2").val()) + parseInt($("#valor1").val());

        $("#resposta").val(resposta);

        return;
    }

    if ($("#valor1").val() != "") {
        $("#resposta").val($("#valor1").val());
    }


    if ($("#valor2").val() != "") {
        $("#resposta").val($("#valor2").val());
    }

};

ObjetoTela.LimparTela = function () {
    $("#valor1").val("");
    $("#valor2").val("");
    $("#resposta").val("");
};

ObjetoTela.BloquearTela = function () {

    var bloquear = false;

    if ($("#bloquear").val() == "Bloquear") {
        bloquear = true;
        $("#bloquear").val("Desbloquear");
    }
    else {
        $("#bloquear").val("Bloquear");
    }


    $("#valor1").prop("disabled", bloquear);
    $("#valor2").prop("disabled", bloquear);

    $("#limpar").prop("disabled", bloquear);

};
/////////////////////////////////////////


// STYLE COM JQUERY
var ObjetoStyleJquery = new Object();

ObjetoStyleJquery.StyleCorFunc = function () {
    var DivNova = $('<div>').attr({ id: "meuStylediv", style: "height:100px;width:100px;background-color:red" });
    $('#div_style').append(DivNova);
}

ObjetoStyleJquery.AlteraStyleCorFunc = function () {

    $('#meuStylediv').css("background-color", "black");
    $('#meuStylediv').css("height", "150px");
    $('#meuStylediv').css("width", "500px");
}

ObjetoStyleJquery.ResetDiv = function () {
    $('#div_style').empty();
}


// DICA ( ANTES DE CHAMAR ESSA FUNÇÃO VERIFIQUE SE O JQUERY JÁ ESTÁ REFERENCIADO)
$(function () {

    //APPEND COM JQUERY 
    $("#Adicionar").click(function () {
        ObjetojavaScript.GerarCampos();
    });

    $("#Limpar").click(function () {
        ObjetojavaScript.limparTela();
    });
    //////////////////////


    // COMPORTAMENTOS 
    $("#valor1").keyup(function () {
        ObjetoTela.validaTela();
    });

    $("#valor2").keyup(function () {
        ObjetoTela.validaTela();
    });

    $("#limpar").click(function () {
        ObjetoTela.LimparTela();
    });

    $("#bloquear").click(function () {
        ObjetoTela.BloquearTela();
    });
    //////////////////////


    // STYLE COM JQUERY  
    $("#styleCor").click(function () {
        ObjetoStyleJquery.StyleCorFunc();
    });

    $("#AltStyleCor").click(function () {
        ObjetoStyleJquery.AlteraStyleCorFunc();
    });

    $("#Reset").click(function () {
        ObjetoStyleJquery.ResetDiv();
    });
    /////////////////////////

});


